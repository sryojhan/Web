#ifndef _GAMESERVER_
#define _GAMESERVER_

#include "GameConnection.h"

class GameServer: public GameConnection{

    private:
        int serverSocket;

    public:
        GameServer(std::string const& ip, int port);
        ~GameServer() override;


        int init() override;
        void shutdown() override;

};

#endif //_GAMESERVER_