#include <string>
#include <iostream>

#include "GameInfo.h"
#include "Definitions.h"

/*
    Proyecto final para la asignatura de RVR
*/

int main(int argc, char** argv){

    GameInfo game(WIDTH, HEIGHT);

    if(game.init()){

        std::cout << game.getError() << "\n";
        return 1;
    }

    game.loop();

    return 0;
}




