#include "Vector.h"



Vector::Vector(): x(0), y(0){

}

Vector::Vector(float x, float y) : x(x), y(y){
    
}

Vector Vector::operator+ (Vector const& other) const{
    return Vector(x + other.x, y + other.y);
}

Vector Vector::operator* (float value) const{
    return Vector(x* value, y * value);
}


float Vector::lerp(float a, float b, float t){

    return (1 - t) * a + b * t;
}

Vector Vector::lerp(Vector const& a, Vector const& b, float t){

    return Vector(lerp(a.x, b.x, t), lerp(a.y, b.y, t));
}