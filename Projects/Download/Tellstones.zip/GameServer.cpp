#include "GameServer.h"
#include <string.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

int GameServer::init() {

    int errors;

    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size;

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);

    if(serverSocket < 0){
        printf("No se ha podido crear el socket del servidor\n");
        return 1;
    }

    memset(&server_addr, '\0', sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = port;
    server_addr.sin_addr.s_addr = inet_addr(ip);

    errors = bind(serverSocket, (struct sockaddr*)
        &server_addr, sizeof(server_addr));

    if(errors < 0){
        printf("Error al hacer el bind. Asegurate de que el puerto no este en uso\n");
        return 1;
    }

    printf("Inicializando el servidor...\n");

    errors = listen(serverSocket, 1);

    printf("Esperando a que el anfitrion se usa a la partida...\n");

    addr_size = sizeof(client_addr);
    
    targetSocket = accept(serverSocket,
        (struct sockaddr*)& client_addr, &addr_size);

    if(targetSocket < 0){
        printf("El anfitrion no se ha podido unir correctamente a la partida\n");
        return 1;
    }

    printf("El anfitrion se ha unido a la partida\n");


    onConnected();
    connected = true;
    return 0;
}

GameServer::GameServer(std::string const& ip, int port): GameConnection(true, ip, port){

}

GameServer::~GameServer(){

    printf("Eliminando servidor\n");

    int errors = close(targetSocket);
    if(errors < 0){
        printf("No se ha podido cerrar el socket del anfitrion correctamente\n");
    }

    errors = close(serverSocket);
    if(errors < 0){
        printf("No se ha podido cerrar el socket del servidor correctamente\n");
    }
}

void GameServer::shutdown(){

    ::shutdown(targetSocket, SHUT_RDWR);
    ::shutdown(serverSocket, SHUT_RDWR);
}