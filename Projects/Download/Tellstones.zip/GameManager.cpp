#include "GameManager.h"

#include "Vector.h"
#include "GameMessage.h"
#include "UIElement.h"
#include "Definitions.h"
#include "Window.h"
#include "GameConnection.h"
#include "Text.h"

#include <iostream>
#include <string>

GameManager::GameManager(int id, std::string const& player1, std::string const& player2): id(1 - id){

    /*
        Inicializacion de todos los atributos de la partida a su estado inicial
    */
    currentPlayer = 0;

    tokens = std::vector<Token>(TOKEN_COUNT, Token());

    tokensPlaced = 0;

    points[0] = points[1] = 0;

    challengeAnswer = -1;
    challengeOcurring = false;

    const int tokenTextureOffet = (int)Textures::Token;
    for(int i = 0; i < TOKEN_COUNT; i++){

        /*
            Inicializacion de cada token, incluida su version de desafio
        */

        Token& token = tokens[i];
        Vector tokenPosition = calculatePiecePosition(i, false);
        token = Token(tokenTextureOffet + i, i, Vector(TOKENSIZE * i, 0), tokenPosition, TOKENSIZE);

        line[i] = -1;
        pile[i] = i;

        token.placed = false;
        token.boardPosition = i;

        challengeTokens.push_back(Token(tokenTextureOffet + i, i, Vector(0, 0), 
            Vector(0, 0), TOKENSIZE));
    }

    /*
        Colocamos las piezas de desafio en su posicion inicial
    */
    adjustChallengePositions();

    holdTimer = lastClickTimer = 0;

    for(int i = 0; i < 2; i++){

        std::string message = "Turno de " + (i == this->id ? player1 : player2);
        names[i] = new Text(message, Vector(WIDTH * 0.5f, TURN_TOP_OFFSET), true);
    }

    gameState = 0;
}

GameManager::~GameManager(){

    delete names[0];
    delete names[1];
}


void GameManager::checkMouseInput(bool const& mouseClicked, bool& doubleclick, bool& mousehold){

    lastClickTimer += delta;

    if(mouseClicked)
    {

        /*
            Para detectar el doble click compruebo si el tiempo que ha pasado desde 
            el ultimo click es inferior al umbral para doble click
        */

        if(lastClickTimer < DOUBLE_CLICK_TIME){

            doubleclick = true;
        }
        lastClickTimer = 0;
    }

    bool mouseBeingPressed = Window::instance->mouseClicked();

    /*
        Para detectar que este manteniendo pulsado el click compruebo que se haya
        mantenido pulsado por encima de un umbral
    */

    if(mouseBeingPressed){
        holdTimer += delta;
    }else{
        holdTimer = 0;
    }

    if(holdTimer > HOLD_TIME){
        mousehold = true;
    }

}



void GameManager::updateGame(Vector const& mousePosition, bool const& mouseClicked){

    names[currentPlayer]->render();
 
    bool doubleclick = false, mousehold = false;
    checkMouseInput(mouseClicked, doubleclick, mousehold);

    /*
        Acutalizo cada uno de los tokens 
    */
    for(Token& token : tokens){

        /*
            Se actualiza la posicion de cada uno de ellos
        */
        token.updatePosition(delta);

        /*
            Compruebo la logica de cada token solo en caso de que no haya 
            ningun otro evento en la partida y que el raton este por encima
            del token. Ademas solo puedes jugar en tu propio turno
        */  
        if(currentPlayer == id && !challengeOcurring && messageToSend.type == GameMessageType::none && token.mouseOverlap(mousePosition)){


            if(mousehold) 
            {

                /*
                    Si se esta manteniendo pulsado el raton podemos diferenciar dos casos:

                        la pieza esta en la pila: entonces le unico caso disponible es colocar la pieza

                        o bien la pieza esta en la linea: en ese caso podremos que estamos en el caso de
                            intercambiar piezas, aunque ese no tiene que ser el caso final necesariamente
                */

                if(!token.placed){

                    messageToSend.type = GameMessageType::place;
                    messageToSend.messageContent.place.token = token.token;

                }
                else
                {

                    messageToSend.type = GameMessageType::swap;
                    messageToSend.messageContent.swap.tokenA = token.token;

                }
            }
            else if(doubleclick){

                /*
                    El evento del doble click solo funciona si la pieza esta escondida
                */

                if(token.placed){
                    
                    /*
                        Para el doble click solo hay dos casos posibles. Se puede esconder una pieza 
                        en caso de que la pieza sea visible o bien se puede echar un vistazo ( de forma privada )
                        a una de las piezas de la linea

                        Ambas acciones son inmediatas por lo que el mensaje se envia desde aqui directamente
                    */

                    if(!token.isHidden()){
                        token.hide();

                        messageToSend.type = GameMessageType::hide;
                        messageToSend.messageContent.hide =  token.token;

                        sendMessage();
                    }

                     
                    else{

                        token.peek();

                        messageToSend.type = GameMessageType::peek;

                        /*
                            Nota: en el caso del peek solo se envia el tipo de mensaje, pues al rival solo le interesa saber
                            que has mirado una pieza, pero le es indiferente de cual
                        */
                        sendMessage();
                    }
                }
               
            }

            /*
            Esta comprobacion es para que la pieza que esta siendo arrastrada no se renderice en dos veces
            */
           if(messageToSend.type == GameMessageType::none || 
                (messageToSend.type == GameMessageType::place && messageToSend.messageContent.place.token != token.token) ||
                (messageToSend.type == GameMessageType::swap && messageToSend.messageContent.swap.tokenA != token.token))
            

            token.renderBackground();
        }

        /*
            Esta comprobacion es para que la pieza que esta siendo arrastrada no se renderice en dos veces
        */

        if(messageToSend.type == GameMessageType::none || 
            (messageToSend.type == GameMessageType::place && messageToSend.messageContent.place.token != token.token) ||
            (messageToSend.type == GameMessageType::swap && messageToSend.messageContent.swap.tokenA != token.token))
            
            token.render();
    }

    /*
        Dibujamos los puntos de cada jugador por pantalla
    */
    drawPoints();

    if(currentPlayer != id)
        return;

    /*
        Si hay un desafio en proceso se le cede el control al resolutor de desafios
    */
    if(challengeOcurring){

        manageChallenge(mousePosition, mouseClicked);
        return;
    }

    /*
        En caso de estar en medio de un evento ( arrastrando un token ) se le cede el control dependiendo
        del tipo que sea. En un caso la pieza sigue en la pila y en el otro la pieza esta en la linea
    */
    if(messageToSend.type != GameMessageType::none)
    {

        switch (messageToSend.type)
        {
        case GameMessageType::place:
                placeToken(mousePosition);
            break;
        
        case GameMessageType::swap:
                lineTokenDrag(mousePosition);
            break;

        default:
            break;
        }
    }
    
}


void GameManager::drawPoints(){
    
    Window* window = Window::instance;

    int pointsTexture = (int)Textures::Point;

    Vector size = Vector(POINTS_SIZE, POINTS_SIZE);

    /*
        Se pintan el numero maximo de puntos para cada jugador.
        Cada punto uno de esos puntos se "enciende" si el jugador ha conseguido 
        esa cantidad de puntos.
        De esa forma, cuando todos los puntos se terminan encendiendo, el jugador gana
    */

    for(int player = 0; player < 2; player++){

        for(int i = 0; i < MAX_POINTS; i++){

            int texture = i >= points[player] ? pointsTexture : pointsTexture + 1;
        
            Vector position(POINTS_XPOS_OFFSET * (i + 1), HEIGHT - POINTS_YPOS_OFFSET);

            if(player == 1){
                position.x = WIDTH - position.x - POINTS_SIZE;
            }

            window->renderTexture(texture, position, size);
        }
    }
}


void GameManager::manageChallenge(Vector const& mousePosition, bool const& mousePressed){


    /*
        Para que el jugador pueda responder correctamente, pintamos una flecha sobre
        la pieza que el jugador debe adivinar
    */


    int arrowTexture = (int) Textures::GameArrow;
    Vector arrowSize = Vector(ARROW_CHALLENGE_SIZE);

    Vector arrowPosition = calculatePiecePosition(tokens[challengeAnswer].boardPosition, true) 
    + Vector((TOKENSIZE - arrowSize.x) * 0.5f, -ARROW_TOP_OFFSET - arrowSize.y);
    
    Window::instance->renderTexture(arrowTexture, arrowPosition, arrowSize);


    /*
        Se actualizan y dibujan todos las piezas auxiliares, y se comprueba si se interactua con alguna de ellas
        Se comprueba si la pieza clickeada es la correcta y dependiendo de ello se actualiza la puntuacion
    */

    for(Token& token: challengeTokens){

        token.updatePosition(delta);

        if(token.mouseOverlap(mousePosition)){
            
            token.renderBackground();

            if(mousePressed){

                int whoScores = 1 - id;
                if(token.token == challengeAnswer){
                    whoScores = id;
                }

                tokens[challengeAnswer].unhide();

                challengeOcurring = false;
                challengeAnswer = -1;

                messageToSend.type = GameMessageType::challengeResponse;
                messageToSend.messageContent.challengeResponse = whoScores;

                sendMessage();

                points[whoScores]++;

                checkScore(whoScores);
            }
        }

        token.render();
    }


}

void GameManager::placeToken(Vector const& mousePosition){

    Token* currentlySelected = &tokens[messageToSend.messageContent.place.token];

    float hsize = -TOKENSIZE * 0.5f;
    currentlySelected->setAtPosition(mousePosition + Vector(hsize, hsize));

    currentlySelected->renderBackground();
    currentlySelected->render();


    if(!Window::instance->mouseClicked()){

        int dir = mousePosition.x + hsize < (WIDTH * 0.5f);
        if(dir){
            placeTokenLeft(currentlySelected->token, currentlySelected->boardPosition);
        }else{
            placeTokenRight(currentlySelected->token, currentlySelected->boardPosition);
        }

        messageToSend.messageContent.place.position = dir;
        
        sendMessage();
    }
}

void GameManager::lineTokenDrag(Vector const& mousePosition){

    /*
        Se coloca la pieza seleccionada en la posicion del cursor y se rendereiza
    */

    Token* currentlySelected = &tokens[messageToSend.messageContent.place.token];

    const float hsize = -TOKENSIZE * 0.5f;
    currentlySelected->setAtPosition(mousePosition + Vector(hsize, hsize));

    currentlySelected->renderBackground();
    currentlySelected->render();


    /*
        En el momento en el que la pieza se suelta pueden haber tres casos:

            -   La pieza cae encima de otra por lo que ambas se cambian de posicion
            -   La pieza cae en la parte superior de la pantalla entonces se trata de un desafio
            -   La pieza cae en cualquier otra partde de la pantalla por lo que no ocurre nada y
                    la pieza vuelve a su sitio

    */

    if(!Window::instance->mouseClicked()){


        /*
            Comienzo un desafio con la pieza seleccionada
        */

        if(currentlySelected->isHidden() && mousePosition.y < CHALLENGE_TOP_OFFSET){

            adjustLinePositions();

            messageToSend.type = GameMessageType::challenge;
            messageToSend.messageContent.challenge = currentlySelected->token;
            
            sendMessage();

            challengeOcurring = true;
            challengeAnswer = currentlySelected->token;
            adjustChallengePositions();
            return;
        }


        /*
            Itero por todas las piezas de la linea y compruebo que la pieza seleccionada 
            y compruebo si he puesto la pieza encima de otra
        */

        Token* tokenB = nullptr;

        for(int i = 0; i < tokensPlaced; i++){

            tokenB = &tokens[line[i]];

            /*
                Comprueba que el token en cuestion no sea el token seleccionado
            */
            if(tokenB->token == messageToSend.messageContent.swap.tokenA){
                tokenB = nullptr;
                continue;
            }

            if(tokenB->mouseOverlap(mousePosition)){
                break;
            }

            tokenB = nullptr;
        }

        /*
            Si no se esta solapando con ningun token regreso el token a su posicion original
        */

        if(tokenB == nullptr){
            

            messageToSend.type = GameMessageType::none;
            adjustLinePositions();
            return;
        }

        /*
            Si he encontrado un token que se solape con el seleccionado los intercambio de posicion
        */

        messageToSend.messageContent.swap.tokenB = tokenB->token;

        swap(messageToSend.messageContent.swap.tokenA, messageToSend.messageContent.swap.tokenB);
       
        sendMessage();
    }
}

void GameManager::swap(int a, int b){

    /*
        Intercambio la posicon del tablero de dos piezas y reajusto las posiciones de la pila
    */

    Token* tokenA = &tokens[a];
    Token* tokenB = &tokens[b];


    int boardpos = tokenA->boardPosition;
    tokenA->boardPosition = tokenB->boardPosition;
    tokenB->boardPosition = boardpos;


    line[tokenA->boardPosition] = tokenA->token;
    line[tokenB->boardPosition] = tokenB->token;


    adjustLinePositions();
}


void GameManager::placeTokenLeft(int token, int currentPosition){

    /*
        Desplazo todos lo tokens a la derecha y coloco el token en la primera posicion
        Recoloco tanto la linea como la pila
    */


    shiftBoardRight();

    tokensPlaced++;

    line[0] = token;
    pile[currentPosition] = -1;

    tokens[token].placed = true;
    tokens[token].boardPosition = 0;

    adjustLinePositions();
    adjustPilePositions();
}


void GameManager::placeTokenRight(int token, int currentPosition){

     /*
        Coloco el token al borde derecho de la linea
        Recoloco tanto la linea como la pila
    */

    line[tokensPlaced] = token;
    pile[currentPosition] = -1;

    tokens[token].placed = true;
    tokens[token].boardPosition = tokensPlaced;

    tokensPlaced++;

    adjustLinePositions();
    adjustPilePositions();
}


void GameManager::shiftBoardRight(){

    /*
        Si hay tokens, desplazo todo los elementos a la derecha

        Compruebo que el token en cuestion exista ( sea mayor que cero )
        y modifico su atributo board position
    */

    if(tokensPlaced == 0) return;

    for(int i = TOKEN_COUNT - 2; i >= 0; i--){

        int next = i + 1; 
        line[next] = line[i];

        if(line[next] >= 0)
            tokens[line[next]].boardPosition = next;
    }
}


void GameManager::adjustPilePositions(){

    int cont = 0;
    for(int i = 0; i < TOKEN_COUNT; i++){

        if(pile[i] >= 0)
            tokens[pile[i]].moveToPosition(calculatePiecePosition(cont++, false));
    }
}

void GameManager::adjustLinePositions(){
    
    for(int i = 0; i < tokensPlaced; i++){

        tokens[line[i]].moveToPosition(calculatePiecePosition(i, true));
    }
}

void GameManager::adjustChallengePositions(){
    
    for(int i = 0; i < TOKEN_COUNT; i++){


        float totalDisplacement = TOKEN_SEPARATION * (TOKEN_COUNT - 1) + TOKENSIZE;

        float firstoken = (WIDTH - totalDisplacement) * 0.5f;

        float xpos = firstoken + TOKEN_SEPARATION * i;

        Vector initialPosition = Vector(xpos, NON_PLACED_TOKEN_OFFSET - TOKENSIZE);

        challengeTokens[i].setAtPosition(initialPosition + Vector(0, HEIGHT * -0.5f));
        challengeTokens[i].moveToPosition(initialPosition);
    }
}


Vector GameManager::calculatePiecePosition(int token, bool placed){

    float height = (placed ? HEIGHT * 0.5f - TOKENSIZE * 0.5f : HEIGHT - NON_PLACED_TOKEN_OFFSET);

    int tokenCount = (placed ? tokensPlaced : TOKEN_COUNT - tokensPlaced);

    float totalDisplacement = TOKEN_SEPARATION * (tokenCount - 1) + TOKENSIZE;

    float initialPosition = (WIDTH - totalDisplacement) * 0.5f;

    float xpos = initialPosition + TOKEN_SEPARATION * token;

    return Vector(xpos, height);
}

void GameManager::sendMessage(){
    if(connection != nullptr){
        connection->sendMessage(messageToSend.to_bin());
    }
    messageToSend.type = GameMessageType::none;

    currentPlayer = 1 - currentPlayer;
}

void GameManager::receiveMessage(GameMessage const& message){

    /*
        Mensaje recibido por el otro jugador
    */

    switch(message.type)
    {
        
        case GameMessageType::place:
        {

            Token* currentlySelected = &tokens[message.messageContent.place.token];

            if(message.messageContent.place.position)
                placeTokenLeft(currentlySelected->token, currentlySelected->boardPosition);
            else
                placeTokenRight(currentlySelected->token, currentlySelected->boardPosition);

            break;
        }

        case GameMessageType::swap:
        {
            
            swap(message.messageContent.swap.tokenA, message.messageContent.swap.tokenB);
            
            break;
        }

        case GameMessageType::hide:
        {

            tokens[message.messageContent.hide].hide();
            break;
        }

        case GameMessageType::challenge:
        {

            challengeOcurring = true;
            challengeAnswer = message.messageContent.challenge;
            adjustChallengePositions();
            break;
        }

        case GameMessageType::challengeResponse:
        {
            
            /*
                Antes de enviar un mensajes guardamos el valor del desafio en una variable 
                para poder utilizarla mas adelante
            */
            tokens[challengeAnswer].unhide();

            int whoScores = message.messageContent.challengeResponse;
            ++points[whoScores];
            checkScore(whoScores);


            challengeOcurring = false;
            challengeAnswer = -1;

            break;
        }

        default:

        break;
    }


    currentPlayer = 1 - currentPlayer;
}


void GameManager::checkScore(int player){

    if(points[player] >= MAX_POINTS){

        gameState = player == id ? 1 : -1;
    }
}


void GameManager::setConnection(GameConnection* con){
    
    connection = con;
}

void GameManager::printLine(){

    for(int i = 0; i < TOKEN_COUNT; i++){
        std::cout << line[i] << " ";
    }
    std::cout << "\n";
}

