#include "Line.h"
#include "Window.h"

#include <iostream>
#include "Definitions.h"

Line::Line(int handleTexture, int backgroundTexture, Vector handleSize, int backgroundHeight, float apparitionTime):
    UIElement(0, Vector(), Vector()), timer(apparitionTime), handleTexture(handleTexture), backgroundTexture(backgroundTexture){


    Vector windowSize = Window::instance->getWindowSize();

    timer = 0;
    maxTime = apparitionTime;

    backgroundSize = Vector(windowSize.x, backgroundHeight);

    initialPosition = -windowSize.x - handleSize.x;
    finalPosition = 0;

    this->backgroundHeight = (windowSize.y - backgroundSize.y) * 0.5f;
    this->handleHeight = (windowSize.y - handleSize.y) * 0.5f;


    size = handleSize;
}


float Line::cubicInterpolation(float t){

    float val = 1 - t;
    return 1 - (val * val * val);
}

void Line::render(){

    if(timer < maxTime){


        timer += delta;


        if(timer > maxTime){
            timer = maxTime;   
        }
    }    


    Window* win = Window::instance;

    Vector position = Vector::lerp(Vector(initialPosition, backgroundHeight), Vector(finalPosition, backgroundHeight), cubicInterpolation(timer / maxTime));

    win->renderTexture(backgroundTexture, position, backgroundSize);

    position.x += backgroundSize.x;
    position.y = handleHeight;


    win->renderTexture(handleTexture, position, size);
}