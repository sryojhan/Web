#ifndef _GAMECONEXION_
#define _GAMECONEXION_

#define BUFFER_SIZE 100

#include <string>
#include <functional>

class GameConnection{

    protected:
        int targetSocket;

        char buffer[BUFFER_SIZE];
        
        bool isServer;

        char ip[20];
        int port;

        bool connected;
        
    public:
        GameConnection(bool isServer, std::string const& ip, int port);

        virtual ~GameConnection() {}

        virtual int init() = 0;

        int receiveMessage();
        int sendMessage(const char* message);
        char* getMessage();

        bool connectionStablished();

        virtual void shutdown();

        std::function<void()> onConnected;

        int target() {
            
            if(targetSocket == 0)
            targetSocket = 10;
            return targetSocket;};
};




#endif