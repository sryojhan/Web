#ifndef _GAMEMESSAGE_
#define _GAMEMESSAGE_

#include <string>

enum class GameMessageType {
    none, place, swap, hide, peek, challenge, challengeResponse
};

class GameMessage
{
    public:
        
        GameMessageType type;

        union info                  //  Message information. The information depends on the message type
        {
            struct TokenPlaced
            {
                int token;
                int position;
            };
            
            struct TokenSwapped
            {
                int tokenA;
                int tokenB;
            };
            

            TokenPlaced place;      //  Token idx to be placed in the line
            TokenSwapped swap;      //  Boths tokens to be interchanged
            
            int hide;               //  Token index of the hidden piece
            int challenge;          //  Index of the challenged token
            int challengeResponse;  //  Player that scored the point

            info();
            ~info();
        };

        info messageContent;

        char* to_bin();
        void from_bin(char*);

        GameMessage();
        ~GameMessage();

    private:

        char* data;
};



#endif