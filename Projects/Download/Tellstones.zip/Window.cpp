#include "Window.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "SDL2/SDL_ttf.h"


#include <string>
#include <iostream>
#include "Vector.h"

Window* Window::instance = nullptr;

Window::Window(){

    window = nullptr;
    renderer = nullptr;

    instance = this;

    mousePressed = mouseJustPressed = false;
    lastKeyPressed = 0;

}

Window::~Window(){
    
    if(window != nullptr) return;

    for(SDL_Texture* tex : textures){
        SDL_DestroyTexture(tex);
    }
    textures.clear();

    for(SDL_Texture* tex : texts){
        if(tex != nullptr)
            SDL_DestroyTexture(tex);
    }
    texts.clear();


    TTF_CloseFont(font);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}


int Window::initWindow(int x, int y){

    int errors;
    errors = SDL_Init(SDL_INIT_VIDEO);

    if(errors)
        return 1;

    window = SDL_CreateWindow("Tellstones", 
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        x, y, 0);

    if(window == nullptr){
        SDL_Quit();
        return 1;
    }

    renderer = SDL_CreateRenderer(window, -1, 0);

    if(renderer == nullptr){
        SDL_DestroyWindow(window);
        window = nullptr;
        SDL_Quit();
        return 1;
    }


    int mask = IMG_INIT_PNG | IMG_INIT_JPG;
    errors = IMG_Init(mask);

    if((errors & mask) != errors){
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        window = nullptr;
        return 1;
    }

    size = Vector(x, y);

    return 0;
}


int Window::initResources(std::string& error){

    std::string texturestoload[] = {"prueba.jpeg", "Button.png", "ButtonPressed.png", "Vignette.png", "Line.png",
        "Ficha1.png", "Ficha2.png", "Ficha3.png", "Ficha4.png", "Ficha5.png", "Ficha6.png", "Ficha7.png", "FichaEscondida.png",
        "Flecha.png", "gameArrow.png", "Point.png", "PointComplete.png"};

    for(std::string & textpath : texturestoload){

        SDL_Surface* surface = IMG_Load(("Assets/" + textpath).c_str());

        if(surface == nullptr){
            error = "No se ha podido cargar la imagen " + textpath + ". Comprueba "
            "que el archivo existe y que se encuentra en la carpeta "
            "correcta";
            return 1;
        }

        SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);

        if(texture == nullptr){
            error = "No se ha podido procesar la imagen " + textpath + ". Comprueba "
            "que tienes instalada la ultima version de SDL_Image";
            return 1;
        }

        SDL_FreeSurface(surface);

        textures.push_back(texture);
    }

    return 0;
}

int Window::initFont(std::string const& fontpath, int fontsize, std::string& errorMessage)
{
    int errors;

    errors = TTF_Init();

    if(errors < 0){

        errorMessage = "Error inicializando el texto. Comprueba que tienes SDL2font instalado en tu maquina";

        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        IMG_Quit();
        window = nullptr;

        return 1;
    }


    font = TTF_OpenFont(("Assets/" + fontpath).c_str(), fontsize);

    if(font == NULL){
        errorMessage = "Error inicializando la fuente. Asegurate de que la fuente existe"
        " y esta en la ruta correcta";
        return 1;
    }

    return 0;
}

void Window::renderTexture(int idx, Vector const& position, Vector const&  size){
    int w, h;
    SDL_QueryTexture(textures[idx], NULL, NULL, &w, &h);

    SDL_Rect src = {0, 0, w, h};
    SDL_Rect dest = {(int)position.x, (int)position.y, (int)size.x, (int)size.y};

    SDL_RenderCopy(renderer, textures[idx], 
        &src, &dest);
}


int Window::createText(std::string const& message, int r, int g, int b){

    SDL_Surface* surf = TTF_RenderText_Solid(font, message.c_str(), {(Uint8)r, (Uint8) g, (Uint8) b, 255});

    int idx = texts.size();

    texts.push_back(SDL_CreateTextureFromSurface(renderer, surf));
    SDL_FreeSurface(surf);
    return idx;
}

void Window::renderText(int idx, Vector const& position){

    int w, h;
    SDL_QueryTexture(texts[idx], NULL, NULL, &w, &h);

    SDL_Rect dest = {(int)position.x, (int)position.y, w, h};
    SDL_RenderCopy(renderer, texts[idx], NULL, &dest);
}


void Window::renderCenteredText(int idx, Vector const& position){

    int w, h;
    SDL_QueryTexture(texts[idx], NULL, NULL, &w, &h);

    SDL_Rect dest = {(int)(position.x - w * 0.5f), (int)(position.y - h * 0.5f), w, h};
    SDL_RenderCopy(renderer, texts[idx], NULL, &dest);
}

void Window::destroyText(int idx){

    SDL_DestroyTexture(texts[idx]);
    texts[idx] = nullptr;
}

Vector Window::textSize(int idx, std::string const& message){
    int w, h;
    TTF_SizeText(font, message.c_str(), &w, &h);
    return Vector(w, h);
}

void Window::tintTexture(int idx, int r, int g, int b){

    if(SDL_SetTextureColorMod(textures[idx], r, g, b)){
        printf("Warning: El coloreado de texturas no esta soportado por el renderer");
    }
}


void Window::render(){

    SDL_RenderPresent(renderer);    
    SDL_RenderClear(renderer);
}


void Window::sleep(float t){
    SDL_Delay(t);
}

bool Window::mouseClicked(){

    return (SDL_GetMouseState(NULL, NULL) & 1) == 1;
}

bool Window::mouseJustClicked(){
    return mouseJustPressed;
}

Vector Window::mousePosition(){

    return currentMousePosition;    
}


void Window::startTextInput(){

    textInput = "";
}

std::string Window::getTextInput()
{
    return textInput;
}

bool Window::manageInput(){

    mouseJustPressed = false;
    lastKeyPressed = 0;

    SDL_Event event;
    while(SDL_PollEvent(&event)){

        if(event.type == SDL_QUIT){
            return true;
        }


        switch (event.type)
        {
            case SDL_TEXTINPUT:

                textInput +=  event.text.text;
                break;

          
            case SDL_KEYDOWN:

                lastKeyPressed =(int)event.key.keysym.scancode;
                if(lastKeyPressed == SDL_SCANCODE_BACKSPACE && textInput.length() > 0){
                    textInput.pop_back();
                }
              
                // std::cout << (int) event.key.keysym.scancode << "\n";
                // std::cout << (int) SDLK_BACKSPACE << "\n";
                // std::cout << "=====" << "\n";

                break;
            case SDL_MOUSEBUTTONDOWN:
                if(!mousePressed)
                mouseJustPressed = true;
                break;
            case SDL_MOUSEBUTTONUP:

                break;
            
            case SDL_MOUSEMOTION:
            {
                int x, y;
                SDL_GetMouseState(&x, &y);
                currentMousePosition = Vector(x, y);
                break;
            }

            default:
                break;
        }
        
    }


    return false;
}


int Window::getLastKeyPressed(){
    return lastKeyPressed;
}

Vector Window::getWindowSize(){
    return size;
}

