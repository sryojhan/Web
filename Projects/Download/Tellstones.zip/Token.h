#ifndef _TOKEN_
#define _TOKEN_


#include "Vector.h"

class Token{

    private:

        float speed;
        float lerpTimer;

        int tokenTexture;

        Vector position;
        
        Vector initial;
        Vector destination;

        float size;

        bool hidden;

        float peekTimer;
    public:

        int token;
        int boardPosition;

        bool placed;

        Token();
        Token(int tokenTexture, int token, Vector initialposition, Vector initialDestination, float size);
        ~Token();

        void updatePosition(float dt);

        void renderBackground();
        void render();

        bool isHidden();
        void hide();
        void unhide();

        void peek();

        bool mouseOverlap(Vector const& position);

        void moveToPosition(Vector const& newposition);

        void setAtPosition(Vector const& newposition);
};


#endif// _TOKEN_