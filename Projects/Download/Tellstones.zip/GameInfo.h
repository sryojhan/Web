#ifndef _GAMEINFO_
#define _GAMEINFO_

#include <vector>
#include <string>
#include <thread>

class Button;
class Window;
class UIElement;
class GameManager;
class GameConnection;
using elements = std::vector<UIElement*>;
using buttons = std::vector<Button*>;


/*
    Enumerado para representar las distintas escenas del juego
*/
enum class GameStates { credentials, lobby, game, count};


/*
    Esta clase maneja las escenas y el contenido de las mismmas.
    Desde esta clase se inicializa la aplicacion y contiene el bucle de juego
*/
class GameInfo{

    private:

        //Atributos del estado de la partida

        Window* window;
        int winWidth, winHeight;

        std::string ip;
        std::string port;
        std::string playername;
        std::string enemyplayer;

        std::string errorMessage;

        int gameState;

        bool exit;
        bool isServer;
        bool initialiseConnection;
        bool otherPlayerDisconnected;

        int gameResult; //  Esta variable guarda el estado de la partida. Cuando no valga 0 significa que algun jugador ha ganado

        elements ui;
        buttons clickies;

        UIElement* vignette;
        UIElement* background;

        GameConnection* connection;
        std::thread connectionThread;


        GameManager* manager;

        /*
            Hilo de creacion de la conexcion y bucle de lectura de mensajes
        */
        void connectionLoop();


        //Los siguientes metodos no son hilos, son solo inicializadores de cada estado de la partida

        /*
            SplashScreen al iniciar el programa
        */
        void initialScreen();

        /*
            Escena en la que introducir los datos del jugador, la ip y el puerto de la partida
        */
        void credentials();

        /*
            Menu principal de juego. Desde esta escena se decide si crear un servido o unise a uno
        */
        void lobby();

        /*
            Escena de busqueda de partida
        */
        void search(std::string const& message);

        /*
            Menu principal de juego. Desde esta escena se decide si crear un servido o unise a uno
        */
        void clearElements();

        /*
            Inicializa los valores del juego
        */
        void game();

    public:
        GameInfo(int width, int height);
        ~GameInfo();

        /*
            Inicializacion de SDL
        */
        bool init();

        /*
            Bucle de juego
        */
        void loop();

        /*
            Devuelve un string con el mensaje del ultimo error ocurrido
        */
        std::string getError();
};



#endif //_GAMEINFO_