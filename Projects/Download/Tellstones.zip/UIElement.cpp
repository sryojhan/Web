#include "UIElement.h"
#include "Window.h"
#include <iostream>

UIElement::UIElement(int textureIdx, Vector position, Vector size): 
    textureIdx(textureIdx), position(position), size(size){
}


void UIElement::render(){
    
    Window::instance->renderTexture(textureIdx, position, size);
}