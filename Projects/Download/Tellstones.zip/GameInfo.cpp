#include "GameInfo.h"

#include "Window.h"
#include "UIElement.h"
#include "Button.h"
#include "GameServer.h"
#include "GameClient.h"
#include "InputField.h"
#include "Text.h"
#include "Scroll.h"
#include "Blink.h"
#include "GameMessage.h"
#include "Line.h"
#include "GameManager.h"

#include <iostream>
#include <string.h>

#include "Definitions.h"


GameInfo::GameInfo(int winWidth, int winHeight): winWidth(winWidth), winHeight(winHeight){

    ip = port = playername = enemyplayer = errorMessage = "";

    vignette = background = nullptr;

    gameState = -1;

    exit = initialiseConnection = otherPlayerDisconnected = false;

    connection = nullptr;

    manager = nullptr;

    gameResult = 0; 

}

bool GameInfo::init(){

    int error;
    window = new Window();

    error = window->initWindow(winWidth, winHeight);

    if(error){
        errorMessage = "Error creando la ventana de SDL."
        "Comprueba que tienes SDL instalado en tu maquina";
        return 1;
    }

    error = window->initResources(errorMessage);

    if(error){

        return 1;
    }

    error = window->initFont("font.ttf", 32, errorMessage);

    if(error){

        return 1;
    }


    background = new Scroll(0, Vector(0.7f, .2f), Vector(winWidth, winHeight));
    vignette = new Image(3, Vector(), Vector(winWidth, winHeight));

 
    return 0;
}

GameInfo::~GameInfo(){
    

    //Este se ejecuta en caso de que la partida haya terminado por abandono del otro jugador
    if(otherPlayerDisconnected || gameResult != 0){

        std::string message;
     
        if(gameResult == 1)
            message = "Ganaste!";
        else if(gameResult == -1)
            message = "Perdiste";
        else
            message = "El rival ha abandonado la partida";
        
        Text* endScreenText = new Text(message, Vector(WIDTH * 0.5f, HEIGHT * 0.5f), true);
        endScreenText->render();
        window->render();
        delete endScreenText;

        while(true){
            if(window->manageInput())
                break;
            window->sleep(10);
        }
    }

    /*
        Este es un caso que ocurre cuando hemos empezado una conexion (siendo el servidor)
        pero si ningun cliente se une el hilo se quedara colgado en el accept esperando una respuesta

        En ese caso hacemos un shutdown del socket para forzar que el hilo se termine
    */
    if(connection != nullptr && !connection->connectionStablished()){
        connection->shutdown();
    }
    connectionThread.join();
    

    clearElements();
    
    delete background;
    delete vignette;

    /*
        Puede que la aplicacion se haya cerrado sin haber llegado a crear ninguna conexion
    */
    if(connection != nullptr)
        delete connection;
        

    if(manager != nullptr)
        delete manager;

    delete window;
}

void GameInfo::loop(){
    
    initialScreen();

    credentials();

    //game();

    connectionThread = std::thread([&](){
        connectionLoop();
    });


    while (!exit)

    {
        /*
            De forma general gameState tiene valor -1
            En caso de que eso no sea asi es porque se desea cambiar de escena
        */

        if(gameState >= 0){

            clearElements();

            if(gameState == (int)GameStates::lobby){

                lobby();
            }
            else if(gameState == (int)GameStates::credentials){

                /*
                    Si volvemos al menu de credenciales tenemos que eliminar la conexion en caso de que se haya creado
                */

                if(connection != nullptr){
                    connection->shutdown();
                    delete connection;
                    connection = nullptr;
                }

                credentials();

            }
            else if(gameState == (int)GameStates::game){

                game();
            }

            //Restauramos el valor de gameState a -1
            gameState = -1;
        }

        bool mouseClicked = window->mouseJustClicked();
        Vector mousePosition = window->mousePosition();


        /*
            Comprobamos si el mouse esta posado sobre un boton
            y en caso de hacer click se ejecuta su accion 
        */
        for(Button* button : clickies){
            bool overlap = button->checkOverlap(mousePosition);

            if(overlap && mouseClicked){
                button->onClick();
            }
        }

        /*
            Lo primero que renderizamos es el fondo y una viñeta que solo afecta a este
        */
        background->render();
        //vignette->render();

        /*
            El metodo render actualiza el valor de cada elemento de la interfaz y lo renderiza
        */
        for(UIElement* elem : ui)
            elem->render();


        /*
            Si estamos en partida actualizamos el estado de juego
        */
        if(manager != nullptr){
            manager->updateGame(mousePosition, mouseClicked);


            /*
                Comprobamos si alguno de los jugadores ha ganado la partida
            */
            gameResult = manager->gameState;
            if(gameResult != 0){
                exit = true;

                if(connection != nullptr)
                    connection->sendMessage("end");
            }
        }

        /*
            Comproamos el input de este frame usando SDL. Si el metodo devuelve true es que se desea cerrar la aplicacion
        */
        if(window->manageInput()){
            exit = true;

            /*
                Si existe una conexion enviamos un mensaje con el valor '0'
                Desde el otro cliente se usa este mensaje para saber si debe terminar la partida
                
                La diferencia de mandar '0' a mandar '\0' es que con el primero sabemos que el 
                jugador ha terminado voluntariamente la partida y la segunda ocurre en caso de un error
            */
            if(connection != nullptr)
                connection->sendMessage((char*)"0");
        }

        window->render();
        window->sleep(SLEEP);
    }
}



void GameInfo::connectionLoop(){


    while(!exit){

        /*
            Esperamos a que el jugador cree una conexion
        */
        while(!initialiseConnection){

            if(exit) return;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        /*
            En caso de error inicializando la conexion se vuelve a intentar conectarse un numero
            determinado de veces
        */
        int tryCount = 0;
        do{
            if(connection == nullptr)
                break;

            if(connection->init())
            {
                
                tryCount++;
                printf("Conexion no establecida, intentandolo de nuevo... (%d/%d) \n", 
                    tryCount, MAX_CONNECTION_TRIES);
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            else{ 
                
                printf("Conexion establecida con exito!\n"); 
                break;
            }

        }while(tryCount < MAX_CONNECTION_TRIES && !exit);

        /*
            Si mientras esperamos a que se establezca la conexion volvemos al menu principal
            se puede dar el caso de que llegados a este punto connection haya sido eliminado

            en ese caso hacemos un continue para volver al principio del bucle (comienzo de connection loop)
        */
        if(connection == nullptr)
            continue;


        /*
            Si se ha llegado a superar el maximo numero de intentos para conectarse volvemos al menu
            de credenciales
        */
        if(tryCount >= MAX_CONNECTION_TRIES){
            printf("Conexion finalizada. Volviendo al menu inicial.\n\n");
            
            initialiseConnection = false;
            gameState = (int)GameStates::credentials;
            continue;
        }

        break;
    }

    /*
        El primer mensaje que se manda una vez establecida la conexion es el nombre del jugador
        Por lo cual enviamos nuestro propio nombre y recibimos el del jugador

        Como lo que enviamos es un char* no es necesario serializar este mensaje
    */

    connection->sendMessage(playername.c_str());
    connection->receiveMessage();
    enemyplayer = connection->getMessage();

    std::cout << enemyplayer << "\n";


    /*
        Este es el bucle principal de lectura de mensajes
    */
    while(!exit){

        int value = connection->receiveMessage();

        /*
            Si el valor devuelto es menor que 0 significa que ha habido un error recibiendo el mensaje
        */
        if(value < 0){
            perror("Error recibiendo el mensaje");
            exit = true;
            continue;
        }

        /*
            Si el valor recibido es 0 significa que se ha recibido un mensaje vacio
            por lo que se ha perdido la conexion con el otro jugador
        */
        if(value == 0){
            printf("Conexion perdida con el otro jugador. Finalizando partida...\n");
            otherPlayerDisconnected = true;
            exit = true;
            break;
        }

        char* message = connection->getMessage();


        /*
            Si el mensaje recibido es "0" significa que el jugador rival ha decidido
            terminar la partida por voluntad propia
        */
        if(strcmp(message, "0") == 0){ //el jugador ha cerrado la aplicacion

            printf("El rival ha abandonado la partida.\n");
            otherPlayerDisconnected = true;
            connection->sendMessage((char*) "\0");
            exit = true;
            break;
        }
        
        if(strcmp(message, "jugar") == 0){
            gameState = (int) GameStates::game;
            continue;
        }

        if(strcmp(message, "end") == 0){
            break;
        }

        /*
            En el caso de que el mensaje no haya sido uno de los anteriores
            procedemos a desserializar el mensaje
        */
        GameMessage mssg;
        mssg.from_bin(message);
        if(manager != nullptr){
            manager->receiveMessage(mssg);
        }
    }

    delete connection;
    connection = nullptr;
 }


 void GameInfo::initialScreen(){
   
    /*
        Escribimos un mensaje y dormimos el hilo un breve periodo de tiempo
    */

    int txtid = window->createText("Welcome");
    window->renderCenteredText(txtid, Vector(winWidth * 0.5f, winHeight * 0.5f));
    window->render();
    window->sleep(1000);
 }

 void GameInfo::credentials(){


    /*
        Tenemos que leer de entrada de teclado tres mensajes: nombre, ip y puerto

        Lo primero que hacemos es desabilitar ip y port para que solo se lea el nombre
        Cada Input Field tiene un puntero a otro lector de input. En el momento en el que se
        pulsa enter, se guarda la cadena escrita actualmente, se desactiva el input y se 
        activa el siguiente en caso de haber. Ademas, tambien se puede añadir un callback
    */

    const int yName = 100, yIp = 250, yPort = 400;

    InputField* inName = new InputField(playername, Vector(winWidth * .5, yName));
    InputField* inIp = new InputField(ip, Vector(winWidth * .5, yIp));
    InputField* inPort = new InputField(port, Vector(winWidth * .5, yPort));


    inIp->enabled = inPort->enabled = false;

    inName->nextInputField = inIp;
    inIp->nextInputField = inPort;

    /*
        El ultimo elemento de vector ui es una flecha, que sirve como feedback al jugador
        indicandole que debe escribir. Cuando se pulse el enter movemos esa flecha a la
        siguiente posicion de input
    */
    inName->onSubmit = [&](){
        static_cast<Blink*>(ui[ui.size() - 1])->setPosition(Vector(winWidth - 100, yIp));
    };

    inIp->onSubmit = [&](){
        static_cast<Blink*>(ui[ui.size() - 1])->setPosition(Vector(winWidth - 100, yPort));
    };

    /*
        Cuando hayamos introducido los tres mensajes, cambiamos la partida al estado lobby
    */
    inPort->onSubmit = [&](){
        gameState = (int) GameStates::lobby;
    };

    ui.push_back(inName);
    ui.push_back(inIp);
    ui.push_back(inPort);


    /*
        Creamos los distintos textos estaticos informativos
    */

    int xText = 20;
    Text* text = new Text("Ingresa tu nombre", Vector(xText, yName));
    ui.push_back(text);

    text = new Text("Ip de la partida", Vector(xText, yIp));
    ui.push_back(text);

    text = new Text("Puerto del juego", Vector(xText, yPort));
    ui.push_back(text);


    /*
        Por ultimo creamos una flecha que sirva como feedback de en que parte de 
        la interfaz nos encontramos
        Ademas dicha flecha ira parpadeando indefinidamente como si se tratase de un cursor
    */
    Blink* arrow = new Blink((int)Textures::Arrow, Vector(winWidth - 100, yName), Vector(50, 50), .02, .02);
    ui.push_back(arrow);
 }

 void GameInfo::lobby(){

    
    std::cout << playername << " " << ip << " " << port << "\n";

    const Vector buttonSize (150, 50);
    
    const Vector createPosition = Vector(winWidth * 0.5f - buttonSize.x - 30, 300);
    const Vector joinPosition = Vector(winWidth * 0.5f + 30, 300);
    const Vector backPosiiton = Vector(winWidth * 0.5f - buttonSize.x * .5f, 500);

    Button* createLobby = new Button(1, createPosition, buttonSize);
    Button* joinLobby = new Button(1, joinPosition, buttonSize);
    Button* back = new Button(1, backPosiiton, buttonSize);

    ui.push_back(createLobby); //0
    ui.push_back(joinLobby); //1
    ui.push_back(back); //2

    clickies.push_back(createLobby);
    clickies.push_back(joinLobby);
    clickies.push_back(back);


    /*
        Al pulsar el boton de unirse la conexion se vuelve la de un servidor
    */
    createLobby->setCallBack([&](){
        if(connection != nullptr)
            return;
        connection = new GameServer(ip, std::stoi(port));
        initialiseConnection = true;
        isServer = true;
        search("Esperando al rival...");
       
    });

    /*
        Al pulsar el boton de unirse la conexion se vuelve la de un cliente
    */
    joinLobby->setCallBack([&](){
         if(connection != nullptr)
            return;
        connection = new GameClient(ip, std::stoi(port));
        initialiseConnection = true;
        search("Conectando con el rival...");
    });
  
    /*
        Al pulsar el boton de atras volvemos a la pantalla de credenciales
    */
    back->setCallBack([&](){
        gameState = (int) GameStates::credentials;
    });

    /*
        Creamos los distintos textos para los botones
    */

    Text* crear = new Text("Crear", createPosition + buttonSize * 0.5f, true);
    Text* unirme = new Text("Unirse", joinPosition + buttonSize * 0.5f, true);
    Text* volver = new Text("Volver", backPosiiton + buttonSize * 0.5f, true);

    ui.push_back(crear); //3
    ui.push_back(unirme); //4
    ui.push_back(volver); //5


    /*
        Escribimos un mensaje saludando al jugador en la parte supeior de la pantalla
    */
    std::string greetingmssg = "Bienvenido " + playername + "!";
    Text* greeting =  new Text(greetingmssg, Vector(winWidth * .5, 20), true);
    ui.push_back(greeting); //6
 }

 void GameInfo::search(std::string const& message){

    /*
        En vez de borrar todos los elementos eliminamos todos menos el ultimo
        El ultimo elemento es el mensaje de saludo y asi conservarlo entre escenas
    */
    UIElement* greetings = ui[ui.size() -1];
    for(int i = 0; i < int(ui.size() - 1); i++){
        delete ui[i];
    }

    ui.clear();
    clickies.clear();

    
    ui.push_back(greetings);

    Text* waiting = new Text(message,
        Vector(winWidth * 0.5f, 300), true);

    ui.push_back(waiting);


    /*
        Callback al cual se llama cuando la conexion del cliente y el servidor ha sido establecida
    */

    connection->onConnected = [&](){

        delete ui[ui.size() -1];
        ui.pop_back();

        Text* waiting = new Text("Esperando a que el anfitrion",
        Vector(winWidth * 0.5f, 200), true);
        ui.push_back(waiting);
        
        waiting = new Text("comience la partida...",
        Vector(winWidth * 0.5f, 250), true);  
        ui.push_back(waiting);

        /*
            En caso de tratarse del servidor creamos un boton para comenzar la partida
        */
        if(isServer){

            Vector buttonSize(150, 50);
            Vector buttonPosition(winWidth * 0.5f - buttonSize.x * 0.5f, winHeight - 200);
            Button* play =  new Button(1, buttonPosition, buttonSize);
            Text* jugar =  new Text("Jugar", buttonPosition + buttonSize * 0.5f, true);

            ui.push_back(play);
            ui.push_back(jugar);

            clickies.push_back(play);

            play->setCallBack([&](){

                gameState = (int) GameStates::game;
                connection->sendMessage("jugar");
            });
        }
    };

 }


 void GameInfo::clearElements(){
     for(UIElement* elem : ui){
        delete elem;
    }

    ui.clear();
    clickies.clear();
 }

 void GameInfo::game(){

    manager = new GameManager(isServer, playername, enemyplayer);
    manager->setConnection(connection);

    Line* line = new Line(2, (int) Textures::Line, Vector(50, 225), 175, 2.0f);
    ui.push_back(line);

 }

 std::string GameInfo::getError(){
    return errorMessage;
 }