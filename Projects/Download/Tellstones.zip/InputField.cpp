#include "InputField.h"
#include "Window.h"
#include <iostream>

InputField::InputField(std::string& input, Vector position) :
    UIElement(-1, position, Vector()), input(input), enabled(true){

    nextInputField = nullptr;
    onSubmit = [](){};
}

void InputField::render(){
    if(enabled){
        
        std::string newinput = Window::instance->getTextInput();

        if(newinput != input){

            if(newinput.length() == 0){

                if(textureIdx >= 0){
                Window::instance->destroyText(textureIdx);
                }
                textureIdx = -1;
                input = "";
                return;
            }

            if(textureIdx >= 0){
                Window::instance->destroyText(textureIdx);
            }

            input = newinput;
            textureIdx = Window::instance->createText(newinput);
        }

        if(input.size() > 0 && Window::instance->getLastKeyPressed() == 40){
            Window::instance->startTextInput();
            if(nextInputField != nullptr){
                nextInputField->enabled = true;
            }
            this->enabled = false;
            onSubmit();
            
        }
    }

    if(textureIdx > 0){

        Window::instance->renderText(textureIdx, position);
    }

}