#ifndef _BLINK_
#define _BLINK_

#include "UIElement.h"



class Blink: public UIElement{

    private:
        float t;
        bool visible;
        float visible_time;
        float invisible_time;
    public:

        Blink(int idx, Vector position, Vector size, float vt, float it);
        void render() override;
        void setPosition(Vector const& newpos);

};




#endif //_BLINK_