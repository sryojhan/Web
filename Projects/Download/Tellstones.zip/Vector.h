#ifndef _VECTOR_
#define _VECTOR_

class Vector{

    public:
        float x, y;
        Vector();
        Vector(float x, float y);

        Vector operator +(Vector const& other) const;
        Vector operator *(float value) const;

        static float lerp(float a, float b, float t);
        static Vector lerp(Vector const& a, Vector const& b, float t);
};

#endif //_VECTOR_