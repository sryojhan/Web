#ifndef _LINE_
#define _LINE_

#include "UIElement.h"

class Line: public UIElement{

    private:

        float timer;
        float maxTime;

        int handleTexture;
        int backgroundTexture;

        float finalPosition;
        float initialPosition;

        float backgroundHeight;
        float handleHeight;

        Vector backgroundSize;

        float cubicInterpolation(float t);

    public:
        Line(int handleTexture, int backgroundTexture, Vector handleSize, int backgroundHeight, float apparitionTime);
        void render() override;
};

#endif