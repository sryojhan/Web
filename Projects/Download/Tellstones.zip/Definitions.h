#ifndef _DEFINITIONS_
#define _DEFINITIONS_

#define TOKEN_COUNT 7

enum class Textures {
    Background, Button, ButtonPressed, Vignette, 
    Line, Token, HidenToken = Token + TOKEN_COUNT,
    Arrow, GameArrow, Point};

#define SLEEP 10
#define THREAD_SLEEP 100

#define WIDTH 600
#define HEIGHT 600

#define MAX_CONNECTION_TRIES 10

#define delta 0.01f

#define TOKENSIZE 50

#define TOKEN_SEPARATION 60

#define NON_PLACED_TOKEN_OFFSET 200

#define MAX_POINTS 3

#define HOLD_TIME 0.1
#define DOUBLE_CLICK_TIME 0.3

#define CHALLENGE_TOP_OFFSET 100

#define PEEK_TIME 1.5

#define cubic(x) 1 - ((1 - x) * (1 - x) * (1 - x))

#define POINTS_SIZE 15
#define POINTS_YPOS_OFFSET 30
#define POINTS_XPOS_OFFSET 25

#define ARROW_CHALLENGE_SIZE 20, 100
#define ARROW_TOP_OFFSET 10


#define TURN_TOP_OFFSET 30

#endif