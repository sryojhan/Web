#ifndef _INPUTFIELD_
#define _INPUTFIELD_


#include "UIElement.h"
#include <string>
#include <functional>


class InputField: public UIElement{


    private:
        std::string& input;

    public:

        InputField(std::string& input, Vector position);
        void render() override;


        bool enabled;
        InputField* nextInputField;
        std::function<void()> onSubmit;
};


#endif //_INPUTFIELD_