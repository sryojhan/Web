
#ifndef _WINDOW_
#define _WINDOW_

#include <vector>
#include "Vector.h"
#include <string>

class SDL_Window;
class SDL_Renderer;
class SDL_Texture;

typedef struct _TTF_Font TTF_Font;

class Window{

    public:
        Window();
        ~Window();

        static Window* instance;

        int initWindow(int x, int y);
        int initResources(std::string& error);
        int initFont(std::string const& font, int fontsize, std::string& errorMessage);

        void render();
        void sleep(float t);

        void tintTexture(int textureIdx, int r = 255, int g = 255, int b = 255);

        void renderTexture(int textureIdx, Vector const&  position, Vector const& size);


        bool manageInput();

        bool mouseJustClicked();
        bool mouseClicked();

        Vector mousePosition();

        int createText(std::string const& message, int r = 255, int g = 255, int b = 255);
        void renderText(int idx, Vector const& position);
        void renderCenteredText(int idx, Vector const& position);
        void destroyText(int idx);
        Vector textSize(int idx, std::string const& message);

        void startTextInput();
        std::string getTextInput();

        int getLastKeyPressed();

        Vector getWindowSize();

        float getDeltaTime();
    private:

        int lastKeyPressed;
        bool mousePressed, mouseJustPressed;
        Vector currentMousePosition;

        SDL_Window* window;
        SDL_Renderer* renderer;

        std::vector<SDL_Texture*> textures;
        std::vector<SDL_Texture*> texts;

        std::string textInput;

        TTF_Font* font;

        Vector size;

};

#endif //_WINDOW_