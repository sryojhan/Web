#include "Scroll.h"
#include "Window.h"

Scroll::Scroll(int idx, Vector speed, Vector size):
    UIElement(idx, Vector(), size), speed(speed){



}



void Scroll::render(){

    Window::instance->renderTexture(textureIdx, position, size);
    Window::instance->renderTexture(textureIdx, position + Vector(size.x, 0), size);
    Window::instance->renderTexture(textureIdx, position + Vector(0, size.y), size);
    Window::instance->renderTexture(textureIdx, position + size, size);

    position.x -= speed.x;
    position.y -= speed.y;

    if(position.x < -size.x)
        position.x += size.x;

    if(position.y < -size.y)
        position.y += size.y;

}