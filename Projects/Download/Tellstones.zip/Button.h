#ifndef _BUTTON_
#define _BUTTON_

#include "UIElement.h"
#include <functional>

using Action = std::function<void()>;

class Button: public UIElement{

    private:
        bool isMouseOverlaping;
        Action callback;
    public:
        Button(int textureIdx, Vector position, Vector size);

        void render() override;

        bool checkClicked();
        bool checkOverlap(Vector mousePosition);

        void setCallBack(Action f);

        void onClick();
};


#endif //_BUTTON_