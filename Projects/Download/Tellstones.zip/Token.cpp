#include "Token.h"
#include "Window.h"
#include "Definitions.h"

Token::Token(){

}

Token::~Token(){

}


Token::Token(int tokenTexture, int token, Vector initialPosition, Vector initialDestination, float size):
    tokenTexture(tokenTexture), size(size), token(token)
{
    boardPosition = -1;
    position = initialPosition;

    initial = initialPosition;
    destination = initialDestination;

    placed = false;

    speed = 1;
    
    hidden = false;

    peekTimer = PEEK_TIME;
}
#include <iostream>
void Token::updatePosition(float dt){

    if(lerpTimer < 1){

        lerpTimer += dt * speed;

        if(lerpTimer >= 1)
            position = destination;          

        else 
            position = Vector::lerp(initial, destination, cubic(lerpTimer));

    }

    if(peekTimer < PEEK_TIME){
        peekTimer += dt;
    }
}

void Token::render(){

    int textureToRender = (hidden && peekTimer >= PEEK_TIME)? (int) Textures::HidenToken : tokenTexture;
    Window::instance->renderTexture(textureToRender, position, Vector(size, size));
}

void Token::renderBackground(){

}

bool Token::mouseOverlap(Vector const& mouse)
{
    float radius = size * 0.5f;
    Vector center = position + Vector(radius, radius);

    Vector dist = (center * -1) + mouse;

    float sqrMgt = dist.x * dist.x + dist.y * dist.y;

    return sqrMgt < radius * radius;
}

void Token::moveToPosition(Vector const& newposition){

    initial = position;
    destination = newposition;

    lerpTimer = 0;
}

void Token::setAtPosition(Vector const& newposition){

    position = newposition;    
    lerpTimer = 1;
}

void Token::hide(){

    hidden = true;
}

void Token::unhide(){

    hidden = false;
}


bool Token::isHidden(){

    return hidden;
}

void Token::peek(){
    peekTimer = 0;
}