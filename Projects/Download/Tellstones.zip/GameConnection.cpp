#include "GameConnection.h"
#include <string.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

GameConnection::GameConnection(bool isServer, std::string const& ip_str, int port):
    isServer(isServer), port(port)
{
    strcpy(ip, ip_str.c_str());
    targetSocket =  0;

    onConnected = [](){};
}

int GameConnection::sendMessage(const char* message){

    return ::send(targetSocket, message, BUFFER_SIZE, 0);
}

int GameConnection::receiveMessage(){

    return ::recv(targetSocket, buffer, BUFFER_SIZE, 0);
}

char* GameConnection::getMessage(){
    return buffer;
}


bool GameConnection::connectionStablished(){
    return connected;
}


void GameConnection::shutdown(){
    printf("me sierro");
    ::shutdown(targetSocket, SHUT_RDWR);
}