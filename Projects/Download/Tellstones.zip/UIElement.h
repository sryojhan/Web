#ifndef _UI_
#define _UI_

#include "Vector.h"

class UIElement{

    protected:
        int textureIdx;    

    public:
        UIElement(int textureIdx, Vector position, Vector size);
        virtual ~UIElement() {};
        virtual void render();

        Vector position;
        Vector size;
};

using Image = UIElement;

#endif //_UI_