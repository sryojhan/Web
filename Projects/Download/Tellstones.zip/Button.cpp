#include "Button.h"
#include "Window.h"
#include <SDL2/SDL.h>

Button::Button(int textureIdx, Vector position, Vector size):
    UIElement(textureIdx, position, size)
{
    callback = [](){};
    isMouseOverlaping = false;
}


void Button::render(){

    // if(isMouseOverlaping)
    //     Window::instance->tintTexture(textureIdx, 100, 100, 100);

  
    int rendertexture = textureIdx + (isMouseOverlaping ? 1 : 0);
    Window::instance->renderTexture(rendertexture, position, size);

    // if(isMouseOverlaping)
    //     Window::instance->tintTexture(textureIdx, 255, 255, 255);
}

bool Button::checkClicked(){
    return isMouseOverlaping && Window::instance->mouseClicked();
}

bool Button::checkOverlap(Vector mouseposition){

    int mousex = (int) mouseposition.x, mousey = (int) mouseposition.y;
    if(mousex > position.x && mousex < position.x + size.x &&
       mousey > position.y && mousey < position.y + size.y){

        isMouseOverlaping = true;
    }
    else{
        isMouseOverlaping = false;
    }

    return isMouseOverlaping;
}

void Button::onClick(){
    callback();
}


void Button::setCallBack(Action f){
    callback = f;
}