#include "Blink.h"


Blink::Blink(int idx, Vector position, Vector size, float vt, float it):
    UIElement(idx, position, size), visible_time(vt), invisible_time(it)

{
    t = 0;
    visible = true;
}


void Blink::render(){

    t +=  visible ? visible_time : invisible_time;

    if(t >= 1){

        t = 0;
        visible = !visible;
    }

    if(visible)
        UIElement::render();

}

void Blink::setPosition(Vector const& newpos){

    t = 0;
    visible = true;
    position = newpos;

}