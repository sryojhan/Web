#include "GameMessage.h"
#include "GameConnection.h"

#include <stdlib.h>
#include <unistd.h>
#include <memory.h>


GameMessage::info::info(){

}

GameMessage::info::~info(){
    
}

GameMessage::GameMessage(){

    type = GameMessageType::none;
    data = nullptr;

}

GameMessage::~GameMessage(){
    if(data != nullptr)
        delete data;
}

void GameMessage::from_bin(char* content){

    char* tmp = content;

    int value;
    memcpy(&value, tmp, sizeof(int));
    tmp += sizeof(int);

    type = (GameMessageType) value;

    switch(type){
        case GameMessageType::place:
            memcpy(&messageContent.place.token, tmp, sizeof(int));
            tmp += sizeof(int);
        
            memcpy(&messageContent.place.position, tmp, sizeof(int));
            break;
        
        case GameMessageType::swap:
            memcpy(&messageContent.swap.tokenA, tmp, sizeof(int));
            tmp += sizeof(int);
        
            memcpy(&messageContent.swap.tokenB, tmp, sizeof(int));
            break;

        case GameMessageType::hide:
            memcpy(&messageContent.hide, tmp, sizeof(int));

            break;
        
        case GameMessageType::challenge:
            memcpy(&messageContent.challenge, tmp, sizeof(int));

            break;
        case GameMessageType::challengeResponse:
            memcpy(&messageContent.challengeResponse, tmp, sizeof(int));

            break;
        default:
            break;
    }
}


char* GameMessage::to_bin(){
    
    if(data != nullptr) 
        delete data;

    data = new char[BUFFER_SIZE];

    char* tmp = data;

    int value = (int) type;
    memcpy(tmp, &value, sizeof(int));
    tmp += sizeof(int);

    switch (type)
    {
    case GameMessageType::place:

        memcpy(tmp, &messageContent.place.token, sizeof(int));
        tmp += sizeof(int);

        memcpy(tmp, &messageContent.place.position, sizeof(int));
        tmp += sizeof(int);

        break;

    case GameMessageType::swap:
        memcpy(tmp, &messageContent.swap.tokenA, sizeof(int));
        tmp += sizeof(int);

        memcpy(tmp, &messageContent.swap.tokenB, sizeof(int));
        tmp += sizeof(int);
        break;

    case GameMessageType::hide:
        memcpy(tmp, &messageContent.hide, sizeof(int));
        break;

    case GameMessageType::challenge:
        memcpy(tmp, &messageContent.challenge, sizeof(int));
        break;

    case GameMessageType::challengeResponse:
        memcpy(tmp, &messageContent.challengeResponse, sizeof(int));
        break;

    default:
        break;
    }
  
    return data;
}