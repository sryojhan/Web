#ifndef _GAMEMANAGER_
#define _GAMEMANAGER_

#include <vector>
#include "Token.h"

#include <vector>

#include "Definitions.h"
#include "GameMessage.h"

class Text;
class Vector;
class UIElement;
class GameConnection;

/*
    Esta clase maneja toda la logica de la partida, desde el renderizado de las fichas, los movimientos de los jugadores, el paso de mensajes
    y estado de juego
*/
class GameManager{

    private:

        //Atributos de la partida

        int id;                     //  id del jugador
        int currentPlayer;          //  id de la persona a la que le toca jugar

        int points[2];              //  Puntos para cada jugador

        int line[TOKEN_COUNT];      //  Array de enteros. Cada entero apunta a un vertice de la pila
        int pile[TOKEN_COUNT];

        std::vector<Token> tokens;              //  Vector de los distintos tokens de la partida
        std::vector<Token> challengeTokens;     //  Vector para los tokens auxiliares ( usados al cambiar de escena )
        
        int tokensPlaced;           //  Numero de tokens colocados

        int challengeAnswer;        //  Respuesta del desafio
        bool challengeOcurring;     //  Hay ahora mismo un desafio en curso?

        float holdTimer, lastClickTimer;    //  Variables de ayuda para detectar doble click y click mantenido pulsado

        GameConnection* connection;         //  Conexion para el paso de mensajes

        GameMessage messageToSend;          //  Estructura con la informacion del mensaje a enviar


        Text* names[2];              //     Texto con el nombre de los jugadores



        //Funcionalidad
        /*
            Desplazar todas las piezas a la derecha. Usado cuando se quiere colocar una pieza por la izquierda
        */
        void shiftBoardRight();             


        /*
            Calcular la posicion que le corresponde a una pieza, de forma que el tablero quede centrado
        */
        Vector calculatePiecePosition(int token, bool placed);


        /*
            Control de la logica para posicionar una pieza sobre le tablero
        */
        void placeToken(Vector const& mousePosition);

        /*
            Coloca una pieza por la izquierda del tablero
        */
        void placeTokenLeft(int token, int currentPosition);
        /*
            Coloca una pieza por la derecha del tablero
        */
        void placeTokenRight(int token, int currentPosition);

        /*
            Centra todas las piezas de la linea
        */
        void adjustLinePositions();
        /*
            Centra todas las piezas de la pila
        */
        void adjustPilePositions();

        /*
            Centra todas las piezas para prepararse ante un desafio
        */
        void adjustChallengePositions();

        /*
            Actualiza las piezas de desafio y maneja la logica del mimsmo. Mientras se este en desafio el resto del juego estara parado
        */
        void manageChallenge(Vector const& mousePosition, bool const& mousePressed);

        /*
            Metodo auxiliar que escribe por consola cada token en orden que este colocado sobre la linea
        */
        void printLine();

        /*
            Intercambia dos piezas de la linea de posicion
        */
        void swap(int tokenA, int tokenB);

        /*
            Manejo del arrastre de una pieza que este colocada sobre la linea. Dependiendo del punto en el que se suelte dicha pieza
            se puede cambiar de lugar con otra o comenzar un desafio
        */
        void lineTokenDrag(Vector const& mousePosition);


        /*
            Comprueba si se ha hecho doble click o si el mouse se ha manteniodo pulsado 
        */
        void checkMouseInput(bool const& mouseClicked, bool& doubleclick, bool& mousehold);
        
        /*
            Prepara el mensaje para ser enviado y lo envia. Restaura los valores del mensaje a uno vacio
        */
        void sendMessage();

        /*
            Comprueba si el jugador ha llegado al maximo de puntos. En caso de ser asi, termina la partida
        */
        void checkScore(int player);


        /*
            Pinta en la pantalla la representacion de los puntos de ambos jugadores
        */
        void drawPoints();
    public:

        /*
            Inicializacion de todos los atributos de la partida a su estado inicial
        */
        GameManager(int id, std::string const& player1, std::string const& player2);
        ~GameManager();

        /*
            Bucle de juego principal
        */
        void updateGame(Vector const& mousePosition, bool const& mouseClicked);

        /*
            Recibe y procesa el mensaje enviado por el otro jugador
        */
        void receiveMessage(GameMessage const& message);

        /*
            Setter de la conexion de la partida
        */  
        void setConnection(GameConnection* connection);


        /*
            Entero con el estado de la partida. Vale 0 si la partida sigue en curso, -1 si el jugaor ha perdido y 1 si el jugador ha ganado
        */
        int gameState;  
};


#endif //_GAMEMANAGER_