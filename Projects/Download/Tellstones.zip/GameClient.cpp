#include "GameClient.h"
#include <string.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

int GameClient::init() {

    int errors;

    struct sockaddr_in addr;

    targetSocket = socket(AF_INET, SOCK_STREAM, 0);

    if(targetSocket < 0){
        printf("No se ha podido crear el socket del anfitrion\n");
        return 1;
    }

    memset(&addr, '\0', sizeof(addr));

    addr.sin_family = AF_INET;
    addr.sin_port = port;
    addr.sin_addr.s_addr = inet_addr(ip);

    errors = connect(targetSocket, (struct sockaddr*) &addr, sizeof(addr));

    if(errors < 0){
        printf("Error al unirse a la partida\n");
        return 1;
    }


    connected = true;
    onConnected();
    return 0;
}

GameClient::GameClient(std::string const& ip, int port): GameConnection(true, ip, port){
    
}

GameClient::~GameClient(){

    printf("Eliminando cliente\n");


    int errors = close(targetSocket);
    if(errors < 0){
        printf("No se ha podido cerrar el socket del anfitrion correctamente\n");
    }
}