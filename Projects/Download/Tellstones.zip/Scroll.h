#ifndef _SCROLL_
#define _SCROLL_


#include "UIElement.h"

class Scroll: public UIElement{


    private:
        Vector speed;

    public:
        Scroll(int idx, Vector speed, Vector size);
        void render() override;

};

#endif //_SCROLL_