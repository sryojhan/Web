#ifndef _TEXT_
#define _TEXT_

#include "UIElement.h"
#include <string>
class Text: public UIElement{

    private:
        bool centered;

    public:
        Text(std::string const&, Vector position, bool centered = false);
        void render() override;
};


#endif //_TEXT_