#ifndef _GAMECLIENT_
#define _GAMECLIENT_

#include "GameConnection.h"

class GameClient: public GameConnection{

    public:
        
        GameClient(std::string const& ip, int port);
        ~GameClient() override;
        
        int init() override;

};

#endif //_GAMECLIENT_