#include "Text.h"
#include "Window.h"


Text::Text(std::string const& message, Vector position, bool centered):
    UIElement(-1, position, Vector()), centered(centered){


        textureIdx = Window::instance->createText(message);
}


void Text::render(){

    if(centered)
        Window::instance->renderCenteredText(textureIdx, position);
    else
        Window::instance->renderText(textureIdx, position);
}