int size = 50;
int speed = 10;

float finishedAnimation = 1;

sortingAlgorithm sort = 
new BubbleSort();
//new SelectionSort();
//new InsertionSort();
//new BogoSort();

float[] values;
int n = 0;
void setup() {
  size(500, 500);

  sort.reset();

  values = createRandomValues(size);

  if (debug)
    sort.sort(values);

  frameRate(10);         
  drawGraph(values);
}
boolean debug = false;
boolean drawInfo = true;

boolean isPressed = false;
boolean isActive = false;
boolean completed = false;

void draw() {
  if (debug) return;

  input();

  if (isActive) {
    for (int i = 0; i < speed; i++) {
      completed = sort.sortWithSteps(values);
    }


    if (completed) {
      textAlign(CENTER);
      textSize(50);
      drawFinishedGraph(values, n);
      n+= size * finishedAnimation / frameRate / 2;
      fill(255);
      text("Sorting complete!", width / 2, height / 2);
    } else {
      drawGraph(values);
    }
  } else {
    textAlign(CENTER);
    textSize(50);
    fill(255);
    text("Currently paused", width / 2, height / 2);
  }

  if (drawInfo) {
    drawSortInfo();
  }
}

void drawFinishedGraph(float[] values, int n) {
  background(10);

  float separation = width / float(size);

  float posx = 0;

  noStroke();

  if (n > size) n = 0;

  fill(100, 255, 100);
  for (int i = 0; i < n; i++) {
    rect(posx, height - values[i], separation, values[i]);
    posx += separation;
  }
  fill(100);

  for (int i = n; i < size; i++) {
    rect(posx, height - values[i], separation, values[i]);
    posx += separation;
  }
}

void drawGraph(float[] values) {
  background(10);

  float separation = width / float(size);

  float posx = 0;

  noStroke();

  int pointOfInterest = sort.results().pointOfInterest;

  fill(100);
  for (int i = 0; i < size; i++) {
    rect(posx, height - values[i], separation, values[i]);
    posx += separation;
  }

  if (isActive) {
    if (pointOfInterest > 0 && pointOfInterest < size) {
      fill(100, 255, 100);
      rect(pointOfInterest * separation, height - values[pointOfInterest], separation, values[pointOfInterest]);
    }

    if (sort.results().specialPoints != null) {
      fill(255, 100, 100);
      for (int value : sort.results().specialPoints) {
        if (value >= 0 && value < size)
          rect(value * separation, height - values[value], separation, values[value]);
      }
    }
  }
}


void input() {
  if (keyPressed) {
    if (!isPressed) {
      isPressed = true;
      if (completed) {
        values = createRandomValues(size);
        isActive = true;

        completed = false;
        n = 0;
        sort.reset();
      } else {
        isActive = !isActive;
        drawGraph(values);
      }
    }
  } else {
    if (isPressed)
      isPressed = false;
  }
}

float[] createRandomValues(int size_) {
  size = size_;
  float[] values = new float[size];
  for (int i = 0; i < size; i++) {
    values[i] = (1 + i) * height / size;
  }


  for (int i = 0; i < size; i++) {
    int r = floor(random(size));
    float temp = values[i];
    values[i] = values[r];
    values[r] = temp;
  }
  return values;
}

void drawSortInfo() {
  sortResult r = sort.results();
  fill(255);
  textSize(16);
  textAlign(LEFT, TOP);
  text(r.name + ": " + size + " elements", 10, 10);
  text("Num. comparisons: " + r.numComparisons, 10, 30);
  text("Array access: " + r.arrayAccess, 10, 50);
}
