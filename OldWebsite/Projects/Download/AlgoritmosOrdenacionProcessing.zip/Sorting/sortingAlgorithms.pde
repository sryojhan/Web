class sortResult {
  int numComparisons = 0;
  int arrayAccess = 0;
  String name = "";
  int pointOfInterest = -1;
  int[] specialPoints = null;
}

interface sortingAlgorithm {
  void sort(float[] values);

  boolean sortWithSteps(float[] values);

  void reset();

  sortResult results();
}


//---------------_BUBBLE_SORT------------------------------------------------------------------------

class BubbleSort implements sortingAlgorithm {
  void sort(float[] values) {
    for (int i = 0; i < size - 1; i++) {
      for (int c = 0; c < size - i - 1; c++) {

        if (values[c] > values[c + 1]) {
          float temp = values[c];
          values[c] = values[c + 1];
          values[c + 1] = temp;
        }
      }
    }
  }

  int i, c;
  boolean finished = false;
  boolean sortWithSteps(float[] values) {
    if (finished) return true;

    result.numComparisons++;
    if (c >= size - i - 1) {
      ++i;
      result.specialPoints[0] = size - i;
      result.numComparisons++;
      if (i >= size - 1) {
        finished = true;
        result.pointOfInterest = -1;
        return true;
      }
      c = 0;
      return false;
    }

    result.numComparisons++;
    result.arrayAccess++;
    if (values[c] > values[c + 1]) {
      result.arrayAccess+= 3;
      float temp = values[c];
      values[c] = values[c + 1];
      values[c + 1] = temp;
      result.specialPoints[1] = c;
    }

    c++;
    result.pointOfInterest = c;
    return false;
  }

  void reset() {
    i = c = 0;
    result.name = "Bubble Sort";
    result.numComparisons = 0;
    result.arrayAccess = 0;
    result.pointOfInterest = -1;
    result.specialPoints = new int[2];
    result.specialPoints[0] = -1;
    result.specialPoints[1] = -1;


    finished = false;
  }

  sortResult result = new sortResult();
  sortResult results() {
    return result;
  }
}


//---------------_INSERTION_SORT------------------------------------------------------------------------

class InsertionSort implements sortingAlgorithm {
  void sort(float[] values) {
    for (int i = 1; i < size; i++) {
      for (int c = i; c > 0 && values[c] < values[c - 1]; c--) {
        float temp = values[c];
        values[c] = values[c - 1];
        values[c - 1] = temp;
      }
    }
  }

  int i = 1, c = i;
  boolean finished = false;
  boolean sortWithSteps(float[] values) {
    if (finished) return true;

    result.numComparisons+= 2;
    result.arrayAccess+= 2;

    if (c <= 0 || values[c] >= values[c - 1]) {
      i++;

      result.numComparisons++;
      if (i >= size) {
        result.pointOfInterest = -1;
        result.specialPoints = null;
        finished = true;
        return true;
      }
      result.specialPoints[1] = c;
      c = i;
      result.pointOfInterest = i;

      return false;
    }

    result.arrayAccess+= 3;
    float temp = values[c];
    values[c] = values[c - 1];
    values[c - 1] = temp;

    c--;

    result.specialPoints[0] = c;
    return false;
  }

  void reset() {
    c = 1;
    i = 0;
    result.name = "Insertion Sort";
    result.numComparisons = 0;
    result.arrayAccess = 0;
    result.pointOfInterest = -1;
    result.specialPoints = new int[2];
    result.specialPoints[0] = -1;
    result.specialPoints[1] = -1;

    finished = false;
  }

  sortResult result = new sortResult();
  sortResult results() {
    return result;
  }
}


//---------------_SELECTION_SORT_------------------------------------------------------------------------


class SelectionSort implements sortingAlgorithm {
  void sort(float[] values) {
    for (int i = 0; i < size - 1; i++) {
      int min = i;

      for (int c = i + 1; c < size; c++) {
        if (values[c] < values[min])
          min = c;
      }

      float temp = values[min];
      values[min] = values[i];
      values[i] = temp;
    }
  }

  int i = 0, c = 1;
  int min = 0;
  boolean finished = false;
  boolean sortWithSteps(float[] values) {
    if (finished) return true;

    result.numComparisons++;
    if (c >= size) {
      result.numComparisons++;
      if (i >= size) {
        finished = true;
        result.pointOfInterest = -1;
        result.specialPoints = null;
        return true;
      }

      result.arrayAccess += 3;
      float temp = values[min];
      values[min] = values[i];
      values[i] = temp;

      i++;
      min = i;
      c = i + 1;


      result.specialPoints[0] = i - 1;
      result.specialPoints[1] = -1;
      return false;
    }

    result.numComparisons++;
    result.arrayAccess += 2;
    if (values[c] < values[min]) {
      min = c;
      result.specialPoints[1] = min;
    }

    c++;
    result.pointOfInterest = c;
    return false;
  }

  void reset() {
    i = 0;
    c = 1;
    min = 0;
    result.name = "Selection Sort";
    result.numComparisons = 0;
    result.arrayAccess = 0;
    result.pointOfInterest = -1;
    finished = false;
    result.specialPoints = new int[2];
    result.specialPoints[0] = -1;
    result.specialPoints[1] = -1;
  }

  sortResult result = new sortResult();
  sortResult results() {
    return result;
  }
}


//---------------_SELECTION_SORT_------------------------------------------------------------------------


class BogoSort implements sortingAlgorithm {

  void sort(float[] values) {
    do{
    for (int i = 0; i < size; i++) {
      int r = floor(random(size));
      float temp =  values[i];
      values[i] = values[r];
      values[r] = temp;
    }
    }while(!isSorted(values));
  }

  boolean isSorted(float[] values) {
    for (int i = 0; i < size - 1; i++) {
      result.arrayAccess += 2;
      result.numComparisons++;
      if (values[i] > values[i + 1])
        return false;
    }
    finished = true;
    return true;
  }

  int i = 0;
  boolean sortWithSteps(float[] values) {
    if(finished) return true;
    result.arrayAccess += size;
    for (int i = 0; i < size; i++) {
      int r = floor(random(size));
      float temp =  values[i];
      values[i] = values[r];
      values[r] = temp;
    }

    result.pointOfInterest = floor(random(size));

    result.specialPoints = new int[floor(random(0, sqrt(size)))];
    for (int i = 0; i < result.specialPoints.length; i++) {
      result.specialPoints[i] = floor(random(size));
    }

    return isSorted(values);
  }

  boolean finished = false;
  void reset() {
    finished = false;
    result.name = "Bogo sort";
    result.numComparisons = 0;
    result.arrayAccess = 0;
    result.pointOfInterest = -1;
    result.specialPoints = new int[floor(random(0, sqrt(size)))];
    for (int i = 0; i < result.specialPoints.length; i++) {
      result.specialPoints[i] = floor(random(size));
    }
  }

  sortResult result = new sortResult();
  sortResult results() {
    return result;
  }
}
